<?php
function search_posts( $args = array() ) {
    $defaults = array(
        'tag'            => '',
        'posts_per_page' => 5,
        'date_query'     => array(),
    );
    $args = wp_parse_args( $args, $defaults );
    $article_Query=new WP_Query( $args );
    if($article_Query->have_posts()){
        while($article_Query->have_posts()){
            $article_Query->the_post();
            echo '<article>';
                echo '<a href=';
                echo the_permalink();
                echo ' class="c-article-card">';    
                echo '<div class=c-article-card__eyecatch>';
                    get_template_part('template-parts/category','label');
                    the_post_thumbnail('medium');
                echo '</div>';
                echo '<div class=c-article-card__title>';
                the_title();
                echo '</div>';
                echo '<div class=c-article-card__text>';
                the_excerpt();
                echo'</div>';
                echo '</a>';
            echo '</article>';
        }
    }else{
        echo 'COMING SOON...';
    }
    wp_reset_postdata();
}





function mytheme_enqueue_styles() {
    // テーマのメインCSS
    wp_enqueue_style('mytheme-style', get_stylesheet_directory_uri().'/scss/style.css');

    // FontAwesome（CDN版）
    wp_enqueue_style(
        'fontawesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
        array(),
        '6.5.1'
    );
}
add_action('wp_enqueue_scripts', 'mytheme_enqueue_styles');
add_theme_support('post-thumbnails');
//set_post_thumbnail($post_id,$thumbnail_id);




?>