<?php get_header(); ?>
<body class="l-body">
    <div class="p-hero">
        <div class="p-hero__main">
                <div class="c-article-card--hero">
                <a href="<?php the_permalink();?>">
                    <div class="c-article-card--hero__eyecatch"><?php the_post_thumbnail('medium');?></div>
                    <div class="c-article-card--hero__title"><?php the_title();?></div>
                </a>
                </div>
        </div>
        <div class="p-hero__sub">
            <div class="p-hero__sub__top">
                <div class="c-article-card--hero">
                    <a href="<?php the_permalink();?>">
                        <div class="c-article-card--hero__eyecatch"><?php the_post_thumbnail('medium');?></div>
                        <div class="c-article-card--hero__title"><?php the_title();?></div>
                    </a>
                </div>
            </div>
            <div class="p-hero__sub__bottom">
                <div class="c-article-card--hero">
                    <a href="<?php the_permalink();?>">
                        <div class="c-article-card--hero__eyecatch"><?php the_post_thumbnail('medium');?></div>
                        <div class="c-article-card--hero__title"><?php the_title();?></div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <main class="l-main">
        <div class="l-home">
            <div class="l-home__title">NEW ARRIVALS</div>
            <div class="l-home__container">
                <?php search_posts(array('posts_per_page'=>7));?>
                <button class="c-button__ShowMore" type="button">VIEW MORE</button>
            </div>
        </div>
        <div class="l-category"></div>
    </main>
</body>
<?php get_footer(); ?>
